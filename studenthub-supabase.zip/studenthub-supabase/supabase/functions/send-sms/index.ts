// Sends queued texts from sms_outbox through Twilio.
// Deploy: supabase functions deploy send-sms
// Secrets: supabase secrets set TWILIO_SID=... TWILIO_TOKEN=... TWILIO_FROM=+1555...
// Schedule it (Dashboard > Integrations > Cron) every minute, or call it after publishing.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
Deno.serve(async () => {
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: rows } = await db.from("sms_outbox").select("*").eq("sent", false).limit(50);
  const sid = Deno.env.get("TWILIO_SID")!, tok = Deno.env.get("TWILIO_TOKEN")!;
  let sent = 0;
  for (const r of rows ?? []) {
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: "POST",
      headers: { Authorization: "Basic " + btoa(`${sid}:${tok}`), "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ To: r.to_phone, From: Deno.env.get("TWILIO_FROM")!, Body: r.body }),
    });
    if (res.ok) { await db.from("sms_outbox").update({ sent: true }).eq("id", r.id); sent++; }
  }
  return new Response(JSON.stringify({ sent }), { headers: { "Content-Type": "application/json" } });
});
